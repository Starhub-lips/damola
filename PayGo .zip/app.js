function displaymessage(){
  
  let mine =document.getElementById("password").value.trim();
  
  let made =document.getElementById("error");
  
  made.innerHTML="";
  
  if (mine==="") {
    made.innerHTML="Can't be empty";
    return;
  } 
  
  
  
  
  
}